package com.runtracker.runtracker;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RunTrackerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RunTrackerApplication.class, args);
	}

}
