package com.runtracker.runtracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RunTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
