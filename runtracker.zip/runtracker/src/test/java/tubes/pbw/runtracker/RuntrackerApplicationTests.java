package tubes.pbw.runtracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RuntrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
